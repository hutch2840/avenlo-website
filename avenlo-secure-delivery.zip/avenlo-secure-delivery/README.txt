AVENLO SECURE STL DELIVERY — WORKSHOP BIN SYSTEM

What this package does:
- Keeps the paid STL ZIP behind a server-side PHP endpoint.
- Verifies the Stripe Checkout Session is paid.
- Verifies the session came from the Workshop Bin System Payment Link.
- Serves the ZIP only after successful verification.
- Direct web access to /protected/ is denied.

HOSTINGER SETUP
1. Deploy download.php and the protected/ folder to the same public_html directory as avenlo.com.au.
2. Copy config.example.php to config.php on the server.
3. Put the LIVE Stripe secret key in config.php. Do NOT put it in GitHub.
4. Confirm PHP cURL is enabled.
5. Test the endpoint only after payment; do not open download.php without a session_id.
6. Update the Stripe Payment Link after_completion redirect to:
   https://avenlo.com.au/download.php?session_id={CHECKOUT_SESSION_ID}

IMPORTANT
- The included ZIP is the customer delivery package.
- The real Stripe secret key is intentionally NOT included.
- The Payment Link must be updated only after the endpoint is deployed, otherwise paid customers could be redirected to an unavailable endpoint.
